 As previous project we will create Deployment for each tier in the project (proxy,backend,database) with 2 replica for each \ 
		Put all project in namespace called webapp \
		mount db-credentials in pods on your host machine \
		Choose which suitable service for grouping each tier \
		Make sure that the proxy pods commincate with the service that you have select for backend pods \
		