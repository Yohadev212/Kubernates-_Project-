We need to build an three tier application (backend,Database,proxy) with docker principles.


	- The backend docker file write in multi-stage approach.
	- The database creadential is in your host machine.
	- Make sure that proxy is up and running in https protocol and the configuration files is in your host machine.
	- Kindly make sure that each container is in seperate network.
	- Make sure that all project is up and down with one command.



Note:You will find backend files in the same path of the project.
